package com.example.alexp.examen2_alejandrofernandez;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.ArrayList;

public class Formulario extends AppCompatActivity {

    private ArrayList<Tareas> listaTareas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulario);

        listaTareas = (ArrayList<Tareas>) getIntent().getSerializableExtra("list");
    }

    public void insertar(View v){
        EditText nombre = (EditText) findViewById(R.id.nombre);
        String n = nombre.getText().toString();
        System.out.println(n);
         boolean prioridad=false;
         if(findViewById(R.id.prioridad).toString().equals("Alta")){
             prioridad=true;
         }
         System.out.println(prioridad);
       Spinner descripcion = (Spinner) findViewById(R.id.descripcion);
        String d = descripcion.getSelectedItem().toString();
         System.out.println(d);
        Tareas t = new Tareas(n,false,prioridad,d);
        listaTareas.add(t);
        Intent intent = new Intent(this, Lista.class);
        intent.putExtra("list", listaTareas);
        startActivity(intent);
    }
    public boolean onCreateOptionsMenu(android.view.Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return  super.onCreateOptionsMenu(menu);
    }
    public void insertar(){
        Intent intent = new Intent(this,Formulario.class);
        intent.putExtra("list",listaTareas);
        startActivity(intent);
    }
    public void ayuda(){
        Intent intent = new Intent(this,Ayuda.class);
        intent.putExtra("list",listaTareas);
        startActivity(intent);

    }

    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.ayuda:
                ayuda();
                return true;
            case R.id.añadir:
                insertar();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
