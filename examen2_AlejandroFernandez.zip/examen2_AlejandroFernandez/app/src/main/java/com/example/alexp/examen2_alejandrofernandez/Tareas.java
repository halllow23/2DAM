package com.example.alexp.examen2_alejandrofernandez;

import java.io.Serializable;

public class Tareas implements Serializable {

    private String nombre;
    private boolean realizada;
    private boolean prioritaria;
    private String descripcion;

    public Tareas(String nombre) {
        this.nombre = nombre;
        realizada = false;
        prioritaria = false;
    }

    public Tareas(String nombre, boolean realizada, boolean prioritaria, String descripcion) {
        this.nombre = nombre;
        this.realizada = realizada;
        this.prioritaria = prioritaria;
        this.descripcion = descripcion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public boolean isRealizada() {
        return realizada;
    }

    public void setRealizada(boolean realizada) {
        this.realizada = realizada;
    }

    public boolean isPrioritaria() {
        return prioritaria;
    }

    public void setPrioritaria(boolean prioritaria) {
        this.prioritaria = prioritaria;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
