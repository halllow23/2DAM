package com.example.alexp.examen2_alejandrofernandez;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Lista extends AppCompatActivity {


    private ListView lista;
    private ArrayList<Tareas> listaTareas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista);

        lista = (ListView) findViewById(R.id.tareas);

        listaTareas = (ArrayList<Tareas>) getIntent().getSerializableExtra("list");
        Adaptador adaptadorTareas = new Adaptador(this, R.layout.activity_modelo_lista, listaTareas);
        lista.setAdapter(adaptadorTareas);

        if(listaTareas.isEmpty()==true){
            Toast.makeText( Lista.this, "No existe ninguna tarea actualmente", Toast.LENGTH_LONG).show();
        }

    }

    public boolean onCreateOptionsMenu(android.view.Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return  super.onCreateOptionsMenu(menu);
    }
    public void insertar(){
        Intent intent = new Intent(this,Formulario.class);
        intent.putExtra("list",listaTareas);
        startActivity(intent);
    }
    public void ayuda(){
        Intent intent = new Intent(this,Ayuda.class);
        intent.putExtra("list",listaTareas);
        startActivity(intent);

    }

    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.ayuda:
                ayuda();
                return true;
            case R.id.añadir:
                insertar();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}
