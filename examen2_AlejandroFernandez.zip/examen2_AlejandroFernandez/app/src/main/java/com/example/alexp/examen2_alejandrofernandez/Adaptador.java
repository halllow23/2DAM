package com.example.alexp.examen2_alejandrofernandez;

import android.content.Context;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Adaptador extends ArrayAdapter<Tareas> {
    Context ctx;
    int layoutTemplate;
    ArrayList<Tareas> lista;

    public Adaptador(@NonNull Context context , @LayoutRes int resource, @NonNull ArrayList<Tareas> object) {
        super(context, resource, object);
        ctx=context;
        layoutTemplate= resource;
        lista= object;
    }
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent){
        View v = LayoutInflater.from(ctx).inflate(layoutTemplate, parent, false);

        Tareas elementoActual = lista.get(position);
        TextView textViewNombre = (TextView) v.findViewById(R.id.Nombre);
        TextView textViewDescripcion = (TextView) v.findViewById(R.id.Descripcion);
        TextView textViewPrioridad = (TextView) v.findViewById(R.id.Prioridad);
        CheckBox ch = (CheckBox) v.findViewById(R.id.Realizado);

        textViewNombre.setText(elementoActual.getNombre());
        textViewDescripcion.setText(elementoActual.getDescripcion());
        if(elementoActual.isPrioritaria()==true){
            textViewPrioridad.setText("Prioridad Alta");
        }else{
            textViewPrioridad.setText("Prioridad Baja");
        }
        if(elementoActual.isRealizada()==true){
            ch.setChecked(true);
        }
        return v;
    }
}
